$(document).ready(function() {


    //alert(userId);
    $('#calendar').css('visibility','visible').addClass('animated fadeInUp');

    $(".closebtn").on('click',function(){
        $("#greetings").html("");
    });

    $("#open-nav").on('click',function(){
        setTimeout(function () {
            $("#greetings").html("Greetings Traveler");
        }, 200);
    });


});
