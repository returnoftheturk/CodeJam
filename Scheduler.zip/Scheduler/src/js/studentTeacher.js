/**
 * Created by rawadkaram on 2016-11-20.
 */

$(document).ready(function(){

    $(".container").hide().fadeIn('slow');

    $.getJSON("json.json", function(data){
        //console.log(data['students']['student1']);
        var url = window.location.href; //Gets the URL of the current page, which containes the userID
        var userId = url.substr(url.indexOf('userid=') + 7);
        var student1 = {};

        $("#schedule").attr('href','student.html?userid='+ userId);
        $("#classes").attr('href','studentClasses.html?userid='+ userId);
        $("#teachers").attr('href','studentTeachers.html?userid='+ userId);

        $.each(data['students'], function(key, val){
            if (userId == val['id']) {
                student1 = data['students'][key];
            }
        });
        $('#fullname').html(student1['name']);
        var classes = student1['classesTaken'].split(','); //list of all classes and their schedules
        var singleClass = []; //array that will hold arrays of each class

        for(var i = 0; i < classes.length; i++){
            var classObject = {}; //Object with class details as properties ---> subject, say, start time, end time
            classObject.title = classes[i].split('-')[0];
            classObject.dow = classes[i].split('-')[1];
            classObject.start = classes[i].split('-')[2];
            classObject.end = classes[i].split('-')[3];
            singleClass.push(classObject);
        }
        //After the first for loop, singleClass will contain the different classObjects
        for(var j = 0; j < singleClass.length; j++){

            //After the second loop, all days will be converted to their equivalent numbers in singleClass
            //Reformat START time
            if(singleClass[j].start.charAt(0) === 'A'){
                // AM
                singleClass[j].start = singleClass[j].start.substr(2);
                singleClass[j].start = singleClass[j].start.replace(/[0-9][0-9]/, /[0-9][0-9]/.exec(singleClass[j].start)+':');
            }else{
                // PM
                var hourStart = /[0-9][0-9]/.exec(singleClass[j].start);
                if(hourStart != '12') {
                    hourStart = parseInt(hourStart) + 12;
                    hourStart = hourStart.toString();
                }
                singleClass[j].start = singleClass[j].start.substr(2);
                singleClass[j].start = singleClass[j].start.replace(/[0-9][0-9]/, hourStart + ":");
            }
            //Reformat END time
            if(singleClass[j].end.charAt(0) === 'A'){
                // AM
                singleClass[j].end = singleClass[j].end.substr(2);
                singleClass[j].end = singleClass[j].end.replace(/[0-9][0-9]/, /[0-9][0-9]/.exec(singleClass[j].end)+':');
            }else{
                // PM
                var hourEnd = /[0-9][0-9]/.exec(singleClass[j].end);
                if(hourEnd != '12') {
                    hourEnd = parseInt(hourEnd) + 12;
                    hourEnd = hourEnd.toString();
                }
                singleClass[j].end = singleClass[j].end.substr(2);
                singleClass[j].end = singleClass[j].end.replace(/[0-9][0-9]/, hourEnd + ":");
            }
            //At this point, singleClass contains an array of objects with reformatted data to be previewed
            //Now we append the container and create divs for each class that the student is signed up for

            $("#row").append('<div class="col-md-11"><div class="singleElement"><h3>Professor ' + singleClass[j].title + '</h3><h4>Teaches ' + singleClass[j].title + '</h4><p>Every ' + singleClass[j].dow + ' from ' + singleClass[j].start +' to ' + singleClass[j].end + '</p></div></div></div>');
        }
        //console.log(singleClass); //for testing purposes

    });


});

