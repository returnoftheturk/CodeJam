$(document).ready(function() {

    $(".fade-in").addClass('animated fadeIn');
    setTimeout(function() {
        $(".img").delay(1000).addClass('animated bounce');
    }, 800);


    $("#student").on("click",function () {
        $('input[id="#username"]').val('');
        $('input[id="#password"]').val('');
        $("#login-form").attr("action","student.html").attr('onsubmit', 'return validateForm()');
        $("#myModalLabel").html("Sign In as Student");
        $("#login-modal").modal("show");

   });
    $("#teacher").on("click",function () {
        $('input[id="#username"]').val('').attr('placeholder', 'Class');
        $('input[id="#password"]').val('').attr('placeholder', 'Password (Class)');
        $("#login-form").attr("action","teacher.html").attr('onsubmit','return validateForm2()');
        $("#myModalLabel").html("Sign In as Teacher");
        $("#login-modal").modal("show");

    });



});
