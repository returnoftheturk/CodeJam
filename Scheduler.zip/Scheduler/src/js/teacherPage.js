/**
 * Created by rawadkaram on 2016-11-20.
 */
$(document).ready(function(){

    $.getJSON("json.json", function(data){

        $('#classes').addClass('animated fadeInUp');

        var url = window.location.href; //Gets the URL of the current page, which containes the userID
        var teacherClass = url.substr(url.indexOf('userid=') + 7); //gets Mathematics, physics etc...

        var sectionVariable = 1;

        $('#professor').html(teacherClass);

        $("#sections").attr('href','teacher.html?userid='+ teacherClass);

        var section = data['classes'][teacherClass];

        $.each(section, function(key, val){

            $.each(val, function(key2, val2){

                if(sectionVariable == 1){ //first section
                    $('.section1-list').append('<li>' + val2['name'] + '</li>');
                }
                else if(sectionVariable == 2){
                    $('.section1-list').append('<li>' + val2['name'] + '</li>');
                }
                console.log(val2);
                sectionVariable = 2;
            });

        });

    });

});
